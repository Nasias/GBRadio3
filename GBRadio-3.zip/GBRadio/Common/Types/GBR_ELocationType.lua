GBR_ELocationType = 
{
    Undefined = 1,
    Character = 2,
    Transmitter = 3,
    Other = 4,
};