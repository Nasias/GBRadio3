GBR_EMessageMethodType = 
{
    Channel = "CHANNEL",
    Guild = "GUILD",
    Raid = "RAID",
    Party = "PARTY",
    Whisper = "WHISPER",
};