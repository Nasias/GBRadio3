GBR_TransmitterModel = GBR_Object:New();

function GBR_TransmitterModel:New(obj)
    
    self.WorldPosX = nil;
    self.WorldPosY = nil;
    self.

    return self:RegisterNew(obj);

end