GBR_EChannelType = 
{
    Guild = "GUILD",
    Raid = "RAID",
    Party = "PARTY",
    Channel = "CHANNEL",
};