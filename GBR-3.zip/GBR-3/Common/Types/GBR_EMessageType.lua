GBR_EMessageType = 
{
    Speech = 1,
    SilentSpeech = 2,
    Emergency = 3,
    WhoIsListening = 4,
    IAmListening = 5,
};