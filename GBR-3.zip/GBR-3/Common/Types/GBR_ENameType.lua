GBR_ENameType = 
{
    Character = 1,
    Mrp = 2,
    Callsign = 3,
    MrpWithCallsign  = 4, 
};