GBR_EGenderType = 
{
    Unknown = 1,
    Male = 2,
    Female = 3,
};