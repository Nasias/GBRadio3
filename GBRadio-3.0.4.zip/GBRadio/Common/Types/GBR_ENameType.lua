GBR_ENameType = 
{
    Character = 1,
    Mrp = 2,
    Callsign = 3,
    CharacterWithCallsign  = 4, 
    MrpWithCallsign  = 5, 
};