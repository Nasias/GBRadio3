GBR_ENotificationGradeType =
{
    Grade1 = 1,
    Grade2 = 2,
    Grade3 = 3,
};