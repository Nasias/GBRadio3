GBR_EMessageInterferenceType = 
{
    None = 1,
    Low = 2,
    High = 3,
    OutOfRange = 4,
};