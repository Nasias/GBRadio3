GBR_ERoleType = 
{
    FLP = 1, -- Front Line Patrol
    POR = 2, -- Public Order Response
    AHO = 3, -- Animal Handling Officer
    AFO = 4, -- Authorised Firearms Officer
    AMO = 5, -- Authorised Magics Officer
    ELS = 6, -- Emergency Life Saver
    EOD = 7, -- Explosive Ordnance Disposal
    IO = 8, -- Intelligence Officer
    JNOPGC = 9, -- JNOP Gold Commander
    JNOPSC = 10, -- JNOP Silver Commander
    JNOPBC = 11, -- JNOP Bronze Commander
};