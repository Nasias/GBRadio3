GBR_ERoleType = 
{
    FLP = 1, -- Front Line Patrol
    POR = 2, -- Public Order Response
    AHO = 3, -- Animal Handling Officer
    AFO = 4, -- Authorised Firearms Officer
    AMO = 5, -- Authorised Magics Officer
    ELS = 6, -- Emergency Life Saver
    EOD = 7, -- Explosive Ordnance Disposal
    JNOPGC = 8, -- JNOP Gold Commander
    JNOPSC = 9, -- JNOP Silver Commander
    JNOPBC = 10, -- JNOP Bronze Commander
};